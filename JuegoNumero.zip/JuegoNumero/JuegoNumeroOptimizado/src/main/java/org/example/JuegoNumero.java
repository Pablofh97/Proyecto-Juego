package org.example;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class JuegoNumero {
    private static final Scanner teclado = new Scanner(System.in);

    public static void main(String[] args) {
        try {
            int opcion = seleccionarModoJuego();

            switch (opcion) {
                case 1:
                    primerModoJuego();
                    break;
                case 2:
                    segundoModoJuego();
                    break;
                case 3:
                    finalizarJuego();
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }

            reiniciarJuego();
        }catch (Exception e){
            System.out.println("Error -->" +e.getClass()+" "+e.getMessage());
        }
    }

    public static int seleccionarModoJuego() {
        int opcion = 0;

        do {
            try {
                System.out.println("Bienvenido al juego de adivinar el número entre 0 y 100.");
                System.out.println("El programa tiene dos modos de juego, elija la opción a la que desee jugar:");
                System.out.println("1. Pistas de mayor o menor.");
                System.out.println("2. Pistas matemáticas.");
                System.out.println("3. Finalizar el juego y salir.");
                System.out.println("----------------------------------------------------------------------------");
                opcion = teclado.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Se debe introducir un número (1 ,2, 3).");
                teclado.nextLine();
            }
        } while (opcion != 1 && opcion != 2 && opcion != 3);

        return opcion;
    }

    public static void finalizarJuego() {
        System.out.println("¡Gracias por jugar! Hasta luego.");
    }

    public static void primerModoJuego() {
        Random numeroRandom = new Random();
        int numeroAdivinar = numeroRandom.nextInt(101);

        System.out.println("Ha elegido las pistas de mayor o menor.");

        int intento;
        boolean acertado = false;

        while (!acertado) {
            System.out.print("Introduce tu intento: ");
            intento = teclado.nextInt();

            if (intento == numeroAdivinar) {
                acertado = true;
                System.out.println("¡Felicidades! ¡Has adivinado el número!");
            } else if (intento < numeroAdivinar) {
                System.out.println("El número a adivinar es mayor. Intenta de nuevo.");
            } else {
                System.out.println("El número a adivinar es menor. Intenta de nuevo.");
            }
        }
    }

    public static void segundoModoJuego() {
        Random random = new Random();
        int numeroAdivinar = random.nextInt(101);

        System.out.println("Ha elegido las pistas matemáticas.");

        int numIntento = 1;
        int intento = -1;
        boolean acertado = false;

        while (!acertado) {
            if (intento == numeroAdivinar) {
                System.out.println("¡Felicidades! ¡Has adivinado el número!");
                acertado = true;
            } else {
                System.out.println("Introduce tu intento número " + numIntento);
            }
            switch (numIntento) {
                case 1:
                    if (numeroAdivinar <= 50) {
                        System.out.println("El número a adivinar está entre [0,50].");
                    } else {
                        System.out.println("El número a adivinar está entre [51,100]. ");
                    }
                    break;
                case 2:
                    System.out.println("El número a adivinar es " + (numeroAdivinar % 2 == 0 ? "par" : "impar"));
                    break;
                case 3:
                    System.out.println("El número a adivinar " + (esPrimo(numeroAdivinar) ? "es" : "no es") + " primo.");
                    break;
                case 4:
                    System.out.println("El número a adivinar " + (esPerfecto(numeroAdivinar) ? "es" : "no es") + " perfecto.");
                    break;
                case 5:
                    System.out.println("El número a adivinar " + (esAbundante(numeroAdivinar) ? "es" : "no es") + " abundante.");
                    break;
                case 6:
                    System.out.println("El número a adivinar " + (esDefectivo(numeroAdivinar) ? "es" : "no es") + " defectivo.");
                    break;
                case 7:
                    System.out.println("El número a adivinar empieza por " + primerDigito(numeroAdivinar));
                    break;
                case 8:
                    System.out.println("El número a adivinar se encuentra entre " + (numeroAdivinar - 1) + " y " + (numeroAdivinar + 1) + ".");
                    break;
                default:
                    break;
            }
            intento = teclado.nextInt();
            numIntento++;
        }
    }

    public static int primerDigito(int numero) {
        return Integer.parseInt(Integer.toString(numero).substring(0, 1));
    }

    public static boolean esPrimo(int numero) {
        if (numero <= 1) return false;
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static boolean esPerfecto(int numero) {
        int suma = 0;
        for (int i = 1; i <= numero / 2; i++) {
            if (numero % i == 0) {
                suma += i;
            }
        }
        return suma == numero;
    }

    public static boolean esDefectivo(int numero) {
        int suma = 0;
        for (int i = 1; i <= numero / 2; i++) {
            if (numero % i == 0) {
                suma += i;
            }
        }
        return numero > suma;
    }

    public static boolean esAbundante(int numero) {
        int suma = 0;
        for (int i = 1; i <= numero; i++) {
            if (numero % i == 0) {
                suma += i;
            }
        }
        return suma > 2 * numero;
    }

    public static void reiniciarJuego() {
        System.out.println("¿Desea volver a jugar? (1: Si / 0: No)");
        int jugarNuevamente = teclado.nextInt();

        if (jugarNuevamente == 1) {
            main(null); // Llamada recursiva para reiniciar el juego
        } else {
            System.out.println("¡Gracias por jugar! Hasta luego.");
        }

        teclado.close();
    }
}
