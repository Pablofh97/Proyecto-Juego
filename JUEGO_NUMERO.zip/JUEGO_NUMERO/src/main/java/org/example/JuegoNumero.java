package org.example;
import java.util.Random;
import java.util.Scanner;
public class JuegoNumero {
    private static Scanner teclado = new Scanner(System.in);
    public static void main(String[] args){
        int opcion = seleccionarModoDeJuego(teclado);
        ModoDeJuego juego = null;

        switch (opcion){
            case 1:
                juego = new MayorOMenor(teclado);
                break;
            case 2:
                juego = new JuegoMatematicas(teclado);
                break;
            case 3:
                finalizarJuego();
                break;
            default:
                System.out.println("opcion no valida");
                break;
        }

        if (juego != null){
            juego.jugable();
        }
        reinciarJuego();
    }

    public static int seleccionarModoDeJuego(Scanner teclado){
        int opcion;
        do {
            System.out.println("este juego trata de adivinar el numero entre 0 y 100");
            System.out.println("el programa tiene 2 modos de juego, elije el juego que deseas jugar:");
            System.out.println("---------------------------------------------------------------------");
            System.out.println("1. adivinar el numero obteniendo pistas mayor o menor");
            System.out.println("2. adivinar el numero obteniendo pistas matematicas");
            System.out.println("3. finalizar el juego");

            opcion = teclado.nextInt();
        }while (opcion != 1 && opcion != 2 && opcion != 3);
        return opcion;
    }

    public static void finalizarJuego(){
        System.out.println("has acabado el juego");
    }

    public static void reinciarJuego(){
        System.out.println("¿quieres volver a jugar? 1.Si || 2.NO");
        int jugarDeNuevo = teclado.nextInt();
        if (jugarDeNuevo == 1){
            main(null); //llamada recursiva para reiniciar el juego
        }else {
            System.out.println("gracias por jugar! xao xao xao xao");
        }
        teclado.close();
    }
}