package org.example;
import java.util.Random;
public class NumeroAleatorio{
   Random numeroRandom = new Random();
    int numeroAdivinar = numeroRandom.nextInt(101);
    public NumeroAleatorio (){
    }
}
