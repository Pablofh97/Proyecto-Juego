package org.example;
import java.util.Random;
import java.util.Scanner;
public class MayorOMenor implements ModoDeJuego{
    private Scanner teclado;

    public MayorOMenor(Scanner teclado){
        this.teclado = teclado;
    }

    @Override
    public void jugable(){
        Random numeroRandom = new Random();
        int numeroAdivinar = numeroRandom.nextInt(101);

        System.out.println("has elegido las pistas de mayor o menor");
        int intento;
        boolean acertado = false;

        while (!acertado){
            System.out.println("introduce el numero que creas que sea el correcto");
            intento = teclado.nextInt();

            if (intento == numeroAdivinar){
                acertado = true;
                System.out.println("¡HAS ADIVINADO EL NUMERO!");
            } else if (intento < numeroAdivinar) {
                System.out.println("el numero ha adivinar es mayor");
            }else {
                System.out.println("el numero a adivinar es menor");
            }
        }
    }
}
