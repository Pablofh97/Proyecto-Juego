package org.example;

/**
 * Clase para obtener las pistas matemáticas.
 */
public class TipoDeNumero {
    /**
     * Método para saber si el primer digito de un entero
     * @param numero numero para su primer digito
     * @return primerDigito
     */
    public static int primerDigito(int numero){
        String numeroCadena = Integer.toString(numero);
        return Character.getNumericValue(numeroCadena.charAt(0));
    }

    /**
     * Método para saber si un numero entero es primo o no
     * @param numero Entero que recibe el método.
     * @return True si es primo, False si no lo es.
     */

    public static boolean esPrimo(int numero){

        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                //Si el número es divisible por algún otro número, no es primo
                return false;
            }
        }
        return true;
    }

    /**
     * Método para saber si un numero es perfecto o no. Un entero es perfecto si es igual a la suma de sus divisores.
     * @param numero Entero que recibe el método.
     * @return True si es perfecto, False si no lo es.
     */
    public static boolean esPerfecto(int numero){
        int suma=0;
        for (int i = numero - 1; i >= 1; i--) {
            if (numero%i == 0){
                suma += i;
            }
        }

        return numero == suma;
    }

    /**
     * Método para saber si un entero es defectivo o no. Un numero es defectivo si la suma de sus divisores es menor que 2 x el numero.
     * @param numero Entero que recibe el método.
     * @return True si es defectivo, False si no lo es.
     */
    public static boolean esDefectivo(int numero){
        int suma=0;
        for (int i = 1 ; i <= 1; i++) {
            suma += i;
        }
        return numero > suma;
    }

    /**
     * Método para saber si un entero es abundante o no. Un entero es abundate si la suma de sus divisores propios es mayor que el propio numero.
     * @param numero Entero que recibe el método.
     * @return True si es abundante, False si no lo es.
     */
    public static boolean esAbundante(int numero){
        int suma=0;
        for (int i = 1; i <= numero ; i++) {
            if (numero%i == 0){
                suma = suma + i;
            }
        }

        return suma > 2 * numero;
    }
}
