package org.example;
public class TipoDeNumero {
    public static int primerDigito(int numero){
        String numeroCadena = Integer.toString(numero);
        int primerDigito = Character.getNumericValue(numeroCadena.charAt(0));
        return primerDigito;
    }

    public static boolean esPrimo(int numero){

        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                //Si el número es divisible por algún otro número, no es primo
                return false;
            }
        }
        return true;
    }

    public static boolean esPerfecto(int numero){
        int suma=0;
        for (int i = numero - 1; i >= 1; i--) {
            if (numero%i == 0){
                suma += i;
            }
        }

        return numero == suma;
    }

    public static boolean esDefectivo(int numero){
        int suma=0;
        for (int i = 1 ; i <= 1; i++) {
            suma += i;
        }
        return numero > suma;
    }

    public static boolean esAbundante(int numero){
        int suma=0;
        for (int i = 1; i <= numero ; i++) {
            if (numero%i == 0){
                suma = suma + i;
            }
        }

        return suma > 2 * numero;
    }
}
