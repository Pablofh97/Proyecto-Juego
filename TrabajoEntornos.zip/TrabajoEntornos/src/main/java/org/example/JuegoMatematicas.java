package org.example;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

/**
 * Clase del segundo modo de juego de pistas matemáticas.
 */
public class JuegoMatematicas implements ModoDeJuego {
    private Scanner teclado;

    public JuegoMatematicas(Scanner teclado) {
        this.teclado = teclado;
    }

    /**
     * Método del segundo modo de juego.
     */
    @Override
    public void jugable() {
        int numeroAdivinar = NumeroAleatorioJuego.generarNumero();
        System.out.println("Has elegido el juego de adivinar el número a traves de pistas matemáticas");
        int numeroIntentos = 1;
        int intento = -1;
        boolean acertado = false;

        try {
            while (!acertado) {
                System.out.println("Introduce el número que creas que sea el correcto");
                intento = teclado.nextInt();

                if (intento == numeroAdivinar) {
                    acertado = true;
                    System.out.println("¡HAS ADIVINADO EL NÚMERO!");
                } else {
                    System.out.println("Introduce el intento número: " + numeroIntentos);
                }

                switch (numeroIntentos) {
                    case 1:
                        if (numeroAdivinar <= 50) {
                            System.out.println("El número ha adivinar está en el intervalo de [0 - 50]");
                        } else {
                            System.out.println("El número ha adivinar está en el intervalo de [51 - 100");
                        }
                        break;

                    case 2:
                        if (numeroAdivinar % 2 == 0) {
                            System.out.println("El número ha adivinar es par");
                        } else {
                            System.out.println("El número ha adivinar es impar");
                        }
                        break;

                    case 3:
                        if (TipoDeNumero.esPrimo(numeroAdivinar)) {
                            System.out.println("El número ha adivinar es primo");
                        } else {
                            System.out.println("El número ha adivinar no es primo");
                        }
                        break;

                    case 4:
                        if (TipoDeNumero.esPerfecto(numeroAdivinar)) {
                            System.out.println("El número ha adivinar es perfecto");
                        } else {
                            System.out.println("El número ha adivinar no es perfecto");
                        }
                        break;

                    case 5:
                        if (TipoDeNumero.esAbundante(numeroAdivinar)) {
                            System.out.println("El número ha adivinar es abundante");
                        } else {
                            System.out.println("El número ha adivinar no es abundante");
                        }
                        break;

                    case 6:
                        if (TipoDeNumero.esDefectivo(numeroAdivinar)) {
                            System.out.println("El número ha adivinar es defectivo");
                        } else {
                            System.out.println("El número ha adivinar no es defectivo");
                        }
                        break;

                    case 7:
                        System.out.println("El número ha adivinar empieza por: " + TipoDeNumero.primerDigito(numeroAdivinar));

                    case 8:
                        System.out.println("El número ha adivinar se encuentra entre " + (numeroAdivinar - 1) + " y " + (numeroAdivinar + 1) + ".");
                        break;
                    default:
                        break;
                }
                numeroIntentos++;
            }
        }catch (InputMismatchException e){
            System.out.println("ERROR! opción no válida. ");
            teclado.nextLine();
        }
    }
}

