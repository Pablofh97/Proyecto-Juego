package org.example;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

/**
 * Clase del modo de juego por pistas tipo mayor o menor.
 */
public class MayorOMenor implements ModoDeJuego{
    private Scanner teclado;

    public MayorOMenor(Scanner teclado){
        this.teclado = teclado;
    }

    /**
     * Método del juego.
     */
    @Override
    public void jugable(){
        int numeroAdivinar = NumeroAleatorioJuego.generarNumero();

        System.out.println("Has elegido las pistas de mayor o menor");
        int intento;
        boolean acertado = false;

        while (!acertado){
            try {
                System.out.println("Introduce el número que creas que sea el correcto: ");
                intento = teclado.nextInt();

                if (intento == numeroAdivinar) {
                    acertado = true;
                    System.out.println("¡HAS ADIVINADO EL NÚMERO!");
                } else if (intento < numeroAdivinar) {
                    System.out.println("El número ha adivinar es mayor");
                } else {
                    System.out.println("El número a adivinar es menor");
                }
            } catch (InputMismatchException e){
                System.out.println("Opción no válida, pruebe de nuevo: ");
                teclado.nextLine();
            }
        }
    }
}
