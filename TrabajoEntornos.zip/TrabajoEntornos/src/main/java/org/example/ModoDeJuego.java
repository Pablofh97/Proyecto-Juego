package org.example;

/**
 * Interfaz de modo de juego.
 */

public interface ModoDeJuego {
     void jugable();
}
