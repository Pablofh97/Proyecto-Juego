package org.example;

public interface ModoDeJuego {
     void jugable();
}
