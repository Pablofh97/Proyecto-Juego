package org.example;

import java.util.Random;

/**
 * Clase para instanciar un numero aleatorio entre [0,1];
 */
public class NumeroAleatorioJuego {
    public static int generarNumero(){
        Random random = new Random();
        return random.nextInt(101);
    }
}
